cp /home/root/config_file/8189es.ko /etc
cp /home/root/config_file/hostapd /bin
cp /home/root/config_file/hostapd_cli /bin
cp /home/root/config_file/udhcpd.conf /etc
cp /home/root/config_file/11b.conf /etc
cp /home/root/config_file/rc.local /etc
echo "*****************copy_done************************"
chmod 777 /etc/rc.local
mount /dev/mmcblk0p1 /mnt/
insmod /etc/8189es.ko > /dev/null
ifconfig wlan0 up
ifconfig wlan0 192.168.2.1
/home/root/ARM_ReceiverAndProtecter &
/home/root/ARM_Worker &                    
udhcpd /etc/udhcpd.conf &
hostapd /etc/11b.conf &
